## Simple Webpage

Another webpage to solidify my knowledge in basic HTML/CSS, i was able to realise it less than 2 hours.

## Motivation

I just wanted to confirm that I aready knew how to build pages in a very efficient way.

## Tech/framework used

Built with :

- HTML
- CSS

# Installation

Just pull the files !

[Elliot](https://www.linkedin.com/in/elliot-garnero/)
